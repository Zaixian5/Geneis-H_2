﻿/*
	20202844 사재헌
	과제2 창세기존-H(2)

	2-1) 분할 컴파일 (O)
	2-2) 맵 만들기 (O)
	2-3) 오브젝트 만들기 - PLAYER (O)
	2-4) 오브젝트 만들기 - ENEMY (O)
	2-5) 충돌 이벤트 (O)
	2-6) 스킬 이펙트 (O)
	2-7) 상태 표시 (O)
	2-8) 스테이지 (O)
	2-9) 추가기능 만들기 (O)

	<스킬>
	z: 수평 방향으로 !를 일직선으로 발사
	x: 수직 방향으로 !를 일직선으로 발사

	<추가기능>
	1. 폭탄: 점수가 정확히 10의 배수가 되면 폭탄이 터져 모든 적을 처치한다.
	2. 점수 서비스: 게임을 시작한지 10초가 지날 때 마다 점수가 10 증가하는 이벤트가 발생한다.
	3. 시간 표시: 맵 하단에 시간이 표시된다.
	4. 통계 표시: 게임 종료시 종료화면에 "점수", "총 처치한 적의 수", "최종 스테이지", "게임 시간"이 출력된다.
*/

#include <stdbool.h>
#include <Windows.h>

#include "cio.h"
#include "common.h"

int main(void)
{
	int key = 0; // key 입력을 저장
	int tick = 0; // 1 tick = 10 ms
	
	intro(); // intro 화면 출력
	print_map(); // 맵 출력
	initialize(); // 모든 적 좌표를 시작 위치로 초기화, 폭탄 효과 배열을 TRUE 혹은 FALSE로 초기화

	while (true)
	{
		Sleep(10); // 프로그램의 진행을 10ms 마다 일시정지
		tick++;
		
		key = get_key(); // 키 입력 값(혹은 입력하지 않았을 때의 값)을 저장
		if (key == K_QUIT) // q를 누르면 게임이 종료된다
		{
			break;
		}
		else if (key == K_ARROW) // 방향키 입력시
		{
			turn_player(); // 플레이어의 좌표를 변경
			player_display(); // 플레이어의 위치를 출력
		}
		else if (key == SKILL_KEY_HORIZONTAL || key == SKILL_KEY_VERTICAL) // z, x 키 입력시
		{
			skill_effect(key); // 스킬 이펙트 출력 및 충돌 이펙트 함수 crash_effect() 호출
		}

		if ((key == K_ARROW) || (key == K_NONE)) 
		{
			if (tick % 20 == 0) // 적의 움직임을 0.2초 마다 처리
			{
				turn_enemy(); // 적의 좌표를 변경
				enemy_display(); // 적의 위치를 출력
			}
		}

		player_enemy_crash(); // 플레이어와 적이 부딪힐 경우 충돌 이펙트 함수 crash_effect() 호출
		bomb_effect(); // 폭탄 효과 함수
		score_service(tick); // 점수 서비스 함수
		print_time(tick); // 게임 시간 출력 함수
	}
	outro(tick); // outro 화면 출력

	return 0;
}